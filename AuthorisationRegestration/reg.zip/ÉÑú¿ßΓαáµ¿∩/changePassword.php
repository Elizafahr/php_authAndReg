<form action="" method="POST">
    <input type="password" name="old_password" placeholder="Старый пароль">
    <br>
    <br>
    <input type="password" name="new_password" placeholder="Новый пароль">
    <br>
    <br>
    <input type="password" name="new_password_confirm" placeholder="Новый пароль">
    <br>
    <br>
    <input type="submit" name="submit">
</form>
<?php
session_start();
$link = new mysqli("localhost", "root", "", "sharov");
$id = $_SESSION['id'];
$query = "SELECT * FROM users WHERE id='$id'";
$result = mysqli_query($link, $query);
$user = mysqli_fetch_assoc($result);
$hash = $user['password'];
$oldPassword = $_POST['old_password'];
$newPassword = $_POST['new_password'];
if(!empty($_POST['submit']))
{
    if (password_verify($oldPassword, $hash)) {
        if($_POST['new_password']==$_POST['new_password_confirm'])
        {
            $newPasswordHash = password_hash($newPassword, PASSWORD_DEFAULT);
            $query = "UPDATE users SET password='$newPasswordHash' WHERE id='$id'";
            mysqli_query($link, $query);
            header("Location: login.php");    
        }
        else
        {
            echo "Пароли не совпадают";
        }
    } else {
        echo "Старый пароль введён неверно";
    }
}
?>

<form action="" method="POST">
    <h1>Авторизация</h1>
    <input name="login" placeholder="Логин">
    <br>
    <br>
    <input name="password" type="password" placeholder="Пароль">
    <br>
    <br>
    <input type="submit">
</form>
<?php
    session_start();
if (!empty($_POST['password']) and !empty($_POST['login'])) {
    $conn = new mysqli("localhost", "root", "", "sharov");
    $login = $_POST['login'];
    $query = "SELECT *, statuses.status_name as status FROM users LEFT JOIN statuses ON users.status_id=statuses.id_status WHERE login='$login'";
    $result = mysqli_query($conn, $query);
    $user = mysqli_fetch_assoc($result);
    if (!empty($user)) {
        $hash = $user['password'];
        if(password_verify($_POST['password'],$hash))
        {
            $_SESSION['auth']=true;
            $_SESSION['id'] = $user['id'];
            $_SESSION['status'] = $user['status'];
        }
        else
        {
        // неверно ввел логин или пароль
        echo "<br> Пароль не подошёл";
        $_SESSION['auth']=false;
        }
    }
    else
    {
        echo "Логин не подошёл";
    }
}
?>
    <!-- Закрыть закрыть текст -->
<?php if (!empty($_SESSION['auth'])): ?>
    <!DOCTYPE html>
    <html>
    <head>
    </head>
    <body>
    <p>текст только для авторизованного пользователя</p>
    </body>
    </html>
<?php else: ?>
    <p>пожалуйста, авторизуйтесь</p>
<?php endif; ?>
<!-- Закрыть часть страницы -->
<!DOCTYPE html>
<html>
<head>
</head>
<body>
<p>текст для любого пользователя</p>
<?php
if (!empty($_SESSION['auth'])) {
    echo 'для авторизованного пользователя <br>';
    echo "<br> <a href='account.php'>Редактировать аккаунт</a>";
    echo "<br> <a href='changePassword.php'>Сменить пароль</a>";
    echo "<br> <a href='delete.php'>Удалить аккаунт</a>";
    echo "<br> <a href='logout.php'>Выйти</a>";
}
?>
<br>
</body>
</html>
<?php
if (!empty($_SESSION['auth']) && $_SESSION['status'] === 'admin') {
    echo "Контент только для админов";
}
?>


